# -*- coding: utf-8 -
#
# This file is part of http_parser released under the MIT license.
# See the NOTICE for more information.

version_info = (0, 9, 0)
__version__ = ".".join(map(str, version_info))
