#include "unrarlib_ext.h"
extern "Python" int CALLBACK PyUNRARCALLBACKStub(UINT,void *,LPARAM,LPARAM);